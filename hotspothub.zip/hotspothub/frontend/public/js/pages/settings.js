async function renderSettings() {
  const s = await api.get('/api/settings');

  document.getElementById('main-content').innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Settings</div><div class="page-sub">Hotspot &amp; account configuration</div></div>
    </div>

    <div style="display:flex;align-items:center;gap:14px;padding:16px 18px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);margin-bottom:14px;">
      <div style="width:48px;height:48px;border-radius:50%;background:var(--blue-bg);display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:600;color:var(--blue-text);">
        ${s.ownerName.split(' ').map(w=>w[0]).join('').slice(0,2)}
      </div>
      <div>
        <div style="font-size:15px;font-weight:600;">${s.ownerName}</div>
        <div style="font-size:12px;color:var(--text2);">Connected to ${s.phoneModel}</div>
      </div>
      <button class="btn btn-sm btn-danger" style="margin-left:auto;" onclick="disconnectPhone()">Disconnect phone</button>
    </div>

    <div class="two-col">
      <div class="card">
        <div class="card-header"><span class="card-title">Hotspot settings</span></div>
        <div class="form-row"><label>Network name (SSID)</label><input type="text" id="s-name" value="${s.hotspotName}"></div>
        <div class="form-row"><label>Password</label><input type="password" id="s-pass" value="${s.password}"></div>
        <div class="form-row"><label>Max devices</label><input type="number" id="s-max" value="${s.maxDevices}" min="1" max="20"></div>
        <div class="form-row"><label>Band</label>
          <select id="s-band">
            <option ${s.band==='5 GHz'?'selected':''}>5 GHz</option>
            <option ${s.band==='2.4 GHz'?'selected':''}>2.4 GHz</option>
            <option ${s.band==='Auto'?'selected':''}>Auto</option>
          </select>
        </div>
        <button class="btn btn-primary" onclick="saveHotspotSettings()">Save changes</button>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">Data &amp; limits</span></div>
        <div class="form-row"><label>Daily limit (MB)</label><input type="number" id="s-limit" value="${s.dailyLimit}"></div>
        <div class="form-row"><label>Alert threshold (MB)</label><input type="number" id="s-alert" value="${s.alertThreshold}"></div>
        <div class="form-row"><label>Auto-block at limit</label>
          <select id="s-autoblock">
            <option ${s.autoBlockAtLimit==='No'?'selected':''}>No</option>
            <option ${s.autoBlockAtLimit==='Yes — block all'?'selected':''}>Yes — block all</option>
            <option ${s.autoBlockAtLimit==='Yes — block streaming'?'selected':''}>Yes — block streaming</option>
          </select>
        </div>
        <hr class="sep">
        <div style="display:flex;flex-direction:column;gap:10px;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <div>
              <div style="font-size:13px;font-weight:500;">Auto-block unknown devices</div>
              <div style="font-size:11px;color:var(--text2);">Block unrecognised devices automatically</div>
            </div>
            <label class="toggle"><input type="checkbox" id="s-autoblockunk" ${s.autoBlockUnknown?'checked':''}>
              <span class="toggle-track"></span><span class="toggle-thumb"></span></label>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <div>
              <div style="font-size:13px;font-weight:500;">Enable schedules</div>
              <div style="font-size:11px;color:var(--text2);">Apply time-based rules</div>
            </div>
            <label class="toggle"><input type="checkbox" id="s-sched" ${s.enableSchedules?'checked':''}>
              <span class="toggle-track"></span><span class="toggle-thumb"></span></label>
          </div>
        </div>
        <button class="btn btn-primary" style="margin-top:12px;" onclick="saveDataSettings()">Save changes</button>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><span class="card-title">Security</span></div>
      <div style="display:flex;flex-direction:column;gap:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <div style="font-size:13px;font-weight:500;">Two-factor login</div>
            <div style="font-size:11px;color:var(--text2);">Require PIN to access dashboard</div>
          </div>
          <label class="toggle"><input type="checkbox" id="s-2fa" ${s.twoFactor?'checked':''} onchange="saveSingleSetting('twoFactor',this.checked)">
            <span class="toggle-track"></span><span class="toggle-thumb"></span></label>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <div style="font-size:13px;font-weight:500;">Auto-logout after inactivity</div>
            <div style="font-size:11px;color:var(--text2);">Log out after 15 min idle</div>
          </div>
          <label class="toggle"><input type="checkbox" id="s-autologout" ${s.autoLogout?'checked':''} onchange="saveSingleSetting('autoLogout',this.checked)">
            <span class="toggle-track"></span><span class="toggle-thumb"></span></label>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <div style="font-size:13px;font-weight:500;">Log all events</div>
            <div style="font-size:11px;color:var(--text2);">Store full activity history</div>
          </div>
          <label class="toggle"><input type="checkbox" id="s-log" ${s.logAllEvents?'checked':''} onchange="saveSingleSetting('logAllEvents',this.checked)">
            <span class="toggle-track"></span><span class="toggle-thumb"></span></label>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><span class="card-title">Phone sync (demo)</span></div>
      <p style="font-size:13px;color:var(--text2);margin-bottom:12px;">Simulate a device joining from your phone (use in production with real companion app).</p>
      <div class="form-row"><label>Device name</label><input type="text" id="sim-name" placeholder="e.g. Laptop Guest"></div>
      <div class="form-row"><label>MAC address</label><input type="text" id="sim-mac" placeholder="AA:BB:CC:DD:EE:FF"></div>
      <button class="btn btn-primary" onclick="simulateDevice()">Simulate device join</button>
    </div>
  </div>`;
}

async function saveHotspotSettings() {
  try {
    await api.put('/api/settings', {
      hotspotName: document.getElementById('s-name').value,
      password: document.getElementById('s-pass').value,
      maxDevices: parseInt(document.getElementById('s-max').value),
      band: document.getElementById('s-band').value,
    });
    toast('Hotspot settings saved!', 'success');
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}

async function saveDataSettings() {
  try {
    await api.put('/api/settings', {
      dailyLimit: parseInt(document.getElementById('s-limit').value),
      alertThreshold: parseInt(document.getElementById('s-alert').value),
      autoBlockAtLimit: document.getElementById('s-autoblock').value,
      autoBlockUnknown: document.getElementById('s-autoblockunk').checked,
      enableSchedules: document.getElementById('s-sched').checked,
    });
    toast('Data settings saved!', 'success');
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}

async function saveSingleSetting(key, value) {
  try {
    await api.put('/api/settings', { [key]: value });
    toast('Setting updated', 'success');
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}

async function simulateDevice() {
  const name = document.getElementById('sim-name').value.trim();
  const mac = document.getElementById('sim-mac').value.trim();
  if (!name || !mac) return toast('Enter device name and MAC address', 'error');
  const icons = { default: '🖥' };
  try {
    await api.post('/api/phone/sync', { devices: [{ name, mac, ip: '192.168.1.' + (Math.floor(Math.random()*200)+10), icon: '🖥', type: 'unknown', speed: 1.0, dataToday: 0 }] });
    toast(`Device "${name}" joined the hotspot!`, 'success');
    document.getElementById('sim-name').value = '';
    document.getElementById('sim-mac').value = '';
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}

async function disconnectPhone() {
  if (confirm('Disconnect your phone from HotspotHub?')) {
    await api.put('/api/settings', { phoneConnected: false });
    toast('Phone disconnected', 'info');
    renderSettings();
  }
}
