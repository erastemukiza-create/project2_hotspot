async function renderDevices() {
  const devices = await api.get('/api/devices');
  const connected = devices.filter(d => d.connected);
  const whitelisted = devices.filter(d => d.whitelisted);
  const blacklisted = devices.filter(d => d.blocked);

  document.getElementById('main-content').innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Devices</div><div class="page-sub">Manage who can connect</div></div>
      <button class="btn btn-primary btn-sm">+ Add to whitelist</button>
    </div>

    <div class="card">
      <div class="card-header"><span class="card-title">Currently connected</span><span class="badge badge-green">${connected.length} online</span></div>
      ${connected.map(d => `
        <div class="item-row" id="dev-row-${d.id}">
          <div class="avatar" style="background:var(--blue-bg)">${d.icon}</div>
          <div class="item-info">
            <div class="item-name">${d.name}</div>
            <div class="item-sub">${d.ip} · MAC: ${d.mac} · ${d.speed} MB/s</div>
          </div>
          ${blockBtnHtml(d)}
        </div>`).join('')}
    </div>

    <div class="two-col">
      <div class="card">
        <div class="card-header"><span class="card-title">Whitelist</span><span class="badge badge-green">trusted</span></div>
        ${whitelisted.length === 0 ? '<p style="color:var(--text2);font-size:13px;">No whitelisted devices.</p>' :
          whitelisted.map(d => `
          <div class="item-row">
            <div class="avatar" style="background:var(--green-bg)">${d.icon}</div>
            <div class="item-info">
              <div class="item-name">${d.name}</div>
              <div class="item-sub">Always allowed · ${d.mac}</div>
            </div>
            <button class="btn btn-sm" onclick="removeWhitelist('${d.id}')">Remove</button>
          </div>`).join('')}
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">Blacklist</span><span class="badge badge-red">blocked</span></div>
        ${blacklisted.length === 0 ? '<p style="color:var(--text2);font-size:13px;">No blocked devices.</p>' :
          blacklisted.map(d => `
          <div class="item-row">
            <div class="avatar" style="background:var(--red-bg)">${d.icon}</div>
            <div class="item-info">
              <div class="item-name">${d.name}</div>
              <div class="item-sub">${d.mac} · Blocked</div>
            </div>
            <button class="btn btn-sm" onclick="toggleBlock('${d.id}',false)">Unblock</button>
          </div>`).join('')}
      </div>
    </div>
  </div>`;
}

async function toggleBlock(id, block) {
  try {
    await api.patch(`/api/devices/${id}`, { blocked: block });
    toast(`Device ${block ? 'blocked' : 'unblocked'}`, block ? 'error' : 'success');
    renderDevices();
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}

async function removeWhitelist(id) {
  try {
    await api.del(`/api/devices/whitelist/${id}`);
    toast('Removed from whitelist', 'info');
    renderDevices();
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}
