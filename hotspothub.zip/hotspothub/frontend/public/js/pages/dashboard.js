async function renderDashboard() {
  const [stats, devices, alerts] = await Promise.all([
    api.get('/api/stats'),
    api.get('/api/devices'),
    api.get('/api/alerts'),
  ]);

  const topDevices = devices.filter(d => d.connected).slice(0, 4);
  const recentAlerts = alerts.slice(0, 3);

  document.getElementById('main-content').innerHTML = `
  <div class="page">
    <div class="page-header">
      <div>
        <div class="page-title">Dashboard</div>
        <div class="page-sub">${new Date().toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}</div>
      </div>
      <span class="badge badge-green">● Hotspot on</span>
    </div>

    <div class="stats-row">
      <div class="stat"><div class="stat-label">Devices</div><div class="stat-val">${stats.connectedDevices}</div><div class="stat-sub">connected now</div></div>
      <div class="stat"><div class="stat-label">Speed</div><div class="stat-val">${stats.totalSpeed} MB/s</div><div class="stat-sub">total</div></div>
      <div class="stat"><div class="stat-label">Data today</div><div class="stat-val">${Math.round(stats.dataUsedToday)} MB</div><div class="stat-sub">across all devices</div></div>
      <div class="stat"><div class="stat-label">Blocked</div><div class="stat-val">${stats.blockedDevices}</div><div class="stat-sub">device(s)</div></div>
    </div>

    <div class="two-col">
      <div class="card">
        <div class="card-header"><span class="card-title">Connected devices</span></div>
        ${topDevices.map(d => `
          <div class="item-row">
            <div class="avatar" style="background:var(--blue-bg)">${d.icon}</div>
            <div class="item-info">
              <div class="item-name">${d.name}</div>
              <div class="item-sub">${d.ip} · ${d.speed} MB/s</div>
            </div>
            ${d.blocked ? '<span class="badge badge-red">Blocked</span>' : '<span class="badge badge-green">Active</span>'}
          </div>`).join('')}
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">Data usage</span><span class="badge badge-gray">today</span></div>
        ${devices.filter(d=>d.connected).map(d => {
          const max = Math.max(...devices.map(x=>x.dataToday||0), 1);
          const pct = Math.round(((d.dataToday||0)/max)*100);
          return `<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
            <span style="font-size:12px;color:var(--text2);width:100px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${d.name}</span>
            <div class="bar-wrap"><div class="bar-fill" style="width:${pct}%;background:var(--blue);"></div></div>
            <span style="font-size:11px;color:var(--text2);min-width:50px;text-align:right;">${d.dataToday||0} MB</span>
          </div>`;
        }).join('')}
      </div>
    </div>

    <div class="card">
      <div class="card-header"><span class="card-title">Recent alerts</span>
        ${stats.unreadAlerts > 0 ? `<span class="badge badge-red">${stats.unreadAlerts} new</span>` : '<span class="badge badge-gray">All read</span>'}
      </div>
      ${recentAlerts.length === 0 ? '<p style="color:var(--text2);font-size:13px;">No recent alerts.</p>' :
        recentAlerts.map(a => `
        <div class="item-row">
          <div class="alert-dot" style="background:${a.type==='Security'?'var(--red)':a.type==='Data'?'var(--yellow)':'var(--green)'}"></div>
          <div class="item-info">
            <div class="item-name">${a.title}</div>
            <div class="item-sub">${a.message} · ${timeAgo(a.time)}</div>
          </div>
          ${makeBadge(a.type)}
        </div>`).join('')}
    </div>
  </div>`;
}
