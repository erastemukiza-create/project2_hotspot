let activeThreadDeviceId = null;

async function renderMessages() {
  const devices = await api.get('/api/devices');
  const connected = devices.filter(d => d.connected && !d.blocked);
  if (!activeThreadDeviceId && connected.length > 0) activeThreadDeviceId = connected[0].id;

  let threadMessages = [];
  if (activeThreadDeviceId) {
    threadMessages = await api.get(`/api/messages/${activeThreadDeviceId}`);
  }

  const activeDevice = connected.find(d => d.id === activeThreadDeviceId);

  document.getElementById('main-content').innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Messages</div><div class="page-sub">Send notifications to connected devices</div></div>
      <button class="btn btn-primary btn-sm" onclick="openBroadcast()">+ Broadcast to all</button>
    </div>

    <div id="broadcast-panel" style="display:none;" class="card">
      <div class="card-header">
        <span class="card-title">Broadcast message</span>
        <button class="btn btn-sm" onclick="document.getElementById('broadcast-panel').style.display='none'">Close</button>
      </div>
      <div style="background:var(--surface2);border-radius:var(--radius);padding:12px;margin-bottom:10px;">
        <div style="font-size:12px;font-weight:500;color:var(--text2);margin-bottom:8px;">Select recipients</div>
        ${connected.map(d => `
          <label style="display:flex;align-items:center;gap:8px;padding:5px 0;font-size:13px;cursor:pointer;">
            <input type="checkbox" class="bc-check" value="${d.id}" checked>
            <span>${d.icon} ${d.name}</span>
          </label>`).join('')}
      </div>
      <textarea id="bc-text" rows="3" placeholder="Type your broadcast message..."></textarea>
      <div style="display:flex;gap:8px;margin-top:8px;align-items:center;">
        <button class="btn btn-primary" onclick="sendBroadcast()">Send to selected</button>
        <span id="bc-confirm" style="font-size:12px;color:var(--green-text);display:none;">✓ Broadcast sent!</span>
      </div>
    </div>

    <div class="two-col-sidebar">
      <div>
        <div class="card" style="padding:10px;">
          <div style="font-size:11px;font-weight:500;color:var(--text2);padding:4px 6px 8px;text-transform:uppercase;letter-spacing:0.4px;">Devices</div>
          ${connected.map(d => `
            <div class="thread-item ${d.id === activeThreadDeviceId ? 'thread-active' : ''}"
                 style="display:flex;align-items:center;gap:9px;padding:9px 8px;border-radius:var(--radius);cursor:pointer;margin-bottom:2px;"
                 onclick="selectThread('${d.id}')">
              <div class="avatar" style="background:var(--blue-bg);width:32px;height:32px;font-size:14px;">${d.icon}</div>
              <div style="flex:1;min-width:0;">
                <div style="font-size:13px;font-weight:500;color:${d.id===activeThreadDeviceId?'var(--blue-text)':'var(--text)'};">${d.name}</div>
                <div style="font-size:11px;color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${d.ip}</div>
              </div>
            </div>`).join('')}
        </div>

        <div class="card">
          <div class="card-title" style="margin-bottom:8px;">Quick messages</div>
          <div style="display:flex;flex-direction:column;gap:5px;">
            <button class="btn btn-sm" style="text-align:left;" onclick="quickFill('Hotspot will restart in 5 minutes. Please save your work.')">⚠ Restart warning</button>
            <button class="btn btn-sm" style="text-align:left;" onclick="quickFill('Your data usage is approaching the daily limit.')">📊 Data limit alert</button>
            <button class="btn btn-sm" style="text-align:left;" onclick="quickFill('You have been disconnected by the admin. Contact us for access.')">🚫 Disconnection notice</button>
            <button class="btn btn-sm" style="text-align:left;" onclick="quickFill('Please review the hotspot rules and policy before continuing.')">📋 Rules reminder</button>
            <button class="btn btn-sm" style="text-align:left;" onclick="quickFill('Heavy usage detected. Please reduce your bandwidth consumption.')">🔻 Bandwidth warning</button>
          </div>
        </div>
      </div>

      <div class="card" style="display:flex;flex-direction:column;">
        ${activeDevice ? `
        <div class="card-header" style="border-bottom:1px solid var(--border);padding-bottom:12px;margin-bottom:0;">
          <div style="display:flex;align-items:center;gap:10px;">
            <div class="avatar" style="background:var(--blue-bg);width:30px;height:30px;font-size:14px;">${activeDevice.icon}</div>
            <div>
              <div style="font-size:13px;font-weight:500;">${activeDevice.name}</div>
              <div style="font-size:11px;color:var(--text2);">${activeDevice.ip} · Online</div>
            </div>
          </div>
          <span class="badge badge-green">Active</span>
        </div>
        <div class="chat-area" id="chat-area" style="flex:1;padding:14px 0;">
          ${threadMessages.length === 0
            ? '<div style="text-align:center;color:var(--text2);font-size:13px;padding:2rem 0;">No messages yet. Send the first one!</div>'
            : threadMessages.map(m => `
              <div style="display:flex;flex-direction:column;">
                ${m.from !== 'admin' ? `<div style="font-size:10px;color:var(--text2);margin-bottom:2px;">${activeDevice.name}</div>` : ''}
                <div class="chat-bubble ${m.from === 'admin' ? 'chat-out' : 'chat-in'}">${m.text}</div>
                <div class="chat-time" style="text-align:${m.from==='admin'?'right':'left'}">${fmtTime(m.time)}</div>
              </div>`).join('')}
        </div>
        <div style="border-top:1px solid var(--border);padding-top:10px;display:flex;gap:8px;">
          <input type="text" id="msg-input" placeholder="Type a message to ${activeDevice.name}..." onkeydown="if(event.key==='Enter')sendMessage()">
          <button class="btn btn-primary" onclick="sendMessage()">Send</button>
        </div>` : `<div style="color:var(--text2);font-size:13px;padding:2rem;text-align:center;">No connected devices found.</div>`}
      </div>
    </div>
  </div>`;

  stylizeThreads();
}

function stylizeThreads() {
  document.querySelectorAll('.thread-item').forEach(el => {
    el.style.background = el.classList.contains('thread-active') ? 'var(--blue-bg)' : 'transparent';
  });
}

async function selectThread(deviceId) {
  activeThreadDeviceId = deviceId;
  await renderMessages();
}

async function sendMessage() {
  const inp = document.getElementById('msg-input');
  const text = inp.value.trim();
  if (!text || !activeThreadDeviceId) return;
  try {
    await api.post('/api/messages', { deviceId: activeThreadDeviceId, text, from: 'admin' });
    inp.value = '';
    toast('Message sent', 'success');
    await renderMessages();
    const chatArea = document.getElementById('chat-area');
    if (chatArea) chatArea.scrollTop = chatArea.scrollHeight;
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}

async function sendBroadcast() {
  const text = document.getElementById('bc-text').value.trim();
  if (!text) return toast('Please type a message', 'error');
  const deviceIds = [...document.querySelectorAll('.bc-check:checked')].map(c => c.value);
  if (deviceIds.length === 0) return toast('Select at least one device', 'error');
  try {
    await api.post('/api/messages/broadcast', { deviceIds, text });
    document.getElementById('bc-confirm').style.display = 'inline';
    document.getElementById('bc-text').value = '';
    toast(`Broadcast sent to ${deviceIds.length} device(s)`, 'success');
    setTimeout(() => {
      const el = document.getElementById('bc-confirm');
      if (el) el.style.display = 'none';
    }, 3000);
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}

function openBroadcast() {
  const p = document.getElementById('broadcast-panel');
  if (p) p.style.display = p.style.display === 'none' ? 'block' : 'none';
}

function quickFill(text) {
  const inp = document.getElementById('msg-input');
  if (inp) { inp.value = text; inp.focus(); }
}
