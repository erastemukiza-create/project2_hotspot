async function renderRules() {
  const rules = await api.get('/api/rules');

  document.getElementById('main-content').innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Rules &amp; policy</div><div class="page-sub">Guidelines shown to all connected devices</div></div>
      <div style="display:flex;gap:8px;">
        <button class="btn btn-sm" onclick="sendRulesToAll()">Send to all devices</button>
      </div>
    </div>

    <div class="notice">
      ⚠ These rules are visible to all connected devices on the captive portal.
      Last updated: ${new Date(rules.lastUpdated).toLocaleDateString()}.
    </div>

    <div class="tab-row">
      <button class="tab-btn active" id="tab-preview-btn" onclick="showRulesTab('preview')">Preview (user view)</button>
      <button class="tab-btn" id="tab-editor-btn" onclick="showRulesTab('editor')">Edit rules</button>
    </div>

    <div id="rules-preview">
      <div class="card">
        <div style="text-align:center;padding:8px 0 18px;">
          <div style="font-size:17px;font-weight:600;color:var(--text);margin-bottom:4px;">${rules.title}</div>
          <div style="font-size:12px;color:var(--text2);">${rules.subtitle}</div>
        </div>

        ${rules.sections.map(sec => `
          <div style="margin-bottom:18px;">
            <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid var(--border);">${sec.title}</div>
            ${sec.rules.map(r => {
              const cls = sec.type === 'warning' && r.id >= 6 ? 'rule-danger' : sec.type === 'warning' ? 'rule-warn' : 'rule-info';
              return `<div class="item-row">
                <div class="rule-num ${cls}">${r.id}</div>
                <div>
                  <div style="font-size:13px;color:var(--text);line-height:1.55;">${r.text}</div>
                  ${r.sub ? `<div style="font-size:11px;color:var(--text2);margin-top:2px;">${r.sub}</div>` : ''}
                </div>
              </div>`;
            }).join('')}
          </div>`).join('')}

        <div style="display:flex;align-items:center;gap:10px;padding:12px 0;border-top:1px solid var(--border);margin-top:4px;">
          <input type="checkbox" id="agree-check" style="width:15px;height:15px;cursor:pointer;">
          <label for="agree-check" style="font-size:13px;cursor:pointer;">I have read and agree to the usage policy</label>
          <button class="btn btn-primary btn-sm" style="margin-left:auto;" onclick="handleAgree()">Connect to network</button>
        </div>
      </div>
    </div>

    <div id="rules-editor" style="display:none;">
      <div class="card">
        <div class="card-header"><span class="card-title">Edit policy</span><span class="badge badge-gray">Markdown supported</span></div>
        <div class="form-row"><label>Policy title</label><input type="text" id="rules-title" value="${rules.title}"></div>
        <div class="form-row"><label>Subtitle</label><input type="text" id="rules-subtitle" value="${rules.subtitle}"></div>
        <div style="margin-bottom:10px;">
          <label style="display:block;font-size:13px;color:var(--text2);margin-bottom:6px;">Policy content</label>
          <textarea id="rules-raw" rows="16" style="font-family:monospace;font-size:12px;">${rules.rawText}</textarea>
        </div>
        <div style="display:flex;gap:8px;align-items:center;">
          <button class="btn btn-primary" onclick="saveRules()">Save changes</button>
          <button class="btn btn-sm" onclick="renderRules()">Discard</button>
          <div style="margin-left:auto;display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text2);">
            Show on login
            <label class="toggle">
              <input type="checkbox" ${rules.visible?'checked':''} onchange="toggleRulesVisible(this.checked)">
              <span class="toggle-track"></span><span class="toggle-thumb"></span>
            </label>
          </div>
        </div>
      </div>
    </div>

    <div style="display:flex;align-items:center;justify-content:space-between;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:12px 18px;">
      <div>
        <div style="font-size:13px;font-weight:500;">Rules visible to connected devices</div>
        <div style="font-size:11px;color:var(--text2);margin-top:2px;">Devices see this policy on first connection</div>
      </div>
      <label class="toggle">
        <input type="checkbox" id="rules-visible-toggle" ${rules.visible?'checked':''} onchange="toggleRulesVisible(this.checked)">
        <span class="toggle-track"></span><span class="toggle-thumb"></span>
      </label>
    </div>
  </div>`;
}

function showRulesTab(tab) {
  document.getElementById('rules-preview').style.display = tab === 'preview' ? 'block' : 'none';
  document.getElementById('rules-editor').style.display = tab === 'editor' ? 'block' : 'none';
  document.getElementById('tab-preview-btn').classList.toggle('active', tab === 'preview');
  document.getElementById('tab-editor-btn').classList.toggle('active', tab === 'editor');
}

async function saveRules() {
  try {
    const current = await api.get('/api/rules');
    const updated = {
      ...current,
      title: document.getElementById('rules-title').value,
      subtitle: document.getElementById('rules-subtitle').value,
      rawText: document.getElementById('rules-raw').value,
      lastUpdated: new Date().toISOString(),
    };
    await api.put('/api/rules', updated);
    toast('Rules saved!', 'success');
    renderRules();
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}

async function toggleRulesVisible(visible) {
  try {
    const current = await api.get('/api/rules');
    await api.put('/api/rules', { ...current, visible });
    toast(`Rules ${visible ? 'visible' : 'hidden'} to devices`, 'info');
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}

async function handleAgree() {
  const checked = document.getElementById('agree-check').checked;
  if (!checked) return toast('Please agree to the policy first', 'error');
  toast('Agreement recorded — device may connect', 'success');
}

async function sendRulesToAll() {
  try {
    const devices = await api.get('/api/devices');
    const active = devices.filter(d => d.connected && !d.blocked);
    const ids = active.map(d => d.id);
    if (ids.length === 0) return toast('No connected devices', 'error');
    await api.post('/api/messages/broadcast', { deviceIds: ids, text: 'Please review the updated hotspot rules and policy at the admin portal.' });
    toast(`Rules sent to ${ids.length} device(s)`, 'success');
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}
