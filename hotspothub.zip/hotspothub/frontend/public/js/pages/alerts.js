// renderAlerts defined in apps.js
