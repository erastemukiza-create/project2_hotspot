// renderSchedules defined in apps.js
