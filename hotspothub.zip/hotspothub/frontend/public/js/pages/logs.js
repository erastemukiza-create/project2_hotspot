// renderLogs defined in apps.js
