// ─── APP CONTROL ─────────────────────────────────────────────────────────────
let appDeviceId = 'd1';
async function renderApps() {
  const [apps, devices, rules] = await Promise.all([
    api.get('/api/apps'),
    api.get('/api/devices'),
    api.get('/api/app-rules'),
  ]);
  const activeDevices = devices.filter(d => d.connected && !d.blocked);
  const categories = [...new Set(apps.map(a => a.category))];
  const ruleMap = {};
  rules.forEach(r => { ruleMap[r.key] = r.allowed; });
  function isAllowed(appId) {
    const key = `${appDeviceId}_${appId}`;
    return ruleMap[key] !== undefined ? ruleMap[key] : true;
  }

  document.getElementById('main-content').innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">App control</div><div class="page-sub">Block or allow apps per device</div></div>
      <select style="width:160px;" onchange="appDeviceId=this.value;renderApps()">
        ${activeDevices.map(d => `<option value="${d.id}" ${d.id===appDeviceId?'selected':''}>${d.name}</option>`).join('')}
      </select>
    </div>
    <div class="two-col">
      ${categories.map(cat => `
        <div class="card">
          <div class="card-header"><span class="card-title">${cat}</span></div>
          ${apps.filter(a=>a.category===cat).map(a => `
            <div class="item-row">
              <div class="avatar" style="background:var(--surface2)">${a.icon}</div>
              <div class="item-info">
                <div class="item-name">${a.name}</div>
                <div class="item-sub">${a.speed} MB/s avg</div>
              </div>
              ${toggleHtml(isAllowed(a.id), appDeviceId, a.id)}
            </div>`).join('')}
        </div>`).join('')}
    </div>
  </div>`;
}

async function toggleApp(deviceId, appId, allowed) {
  try {
    await api.patch(`/api/apps/${deviceId}/${appId}`, { allowed });
    toast(`App ${allowed ? 'allowed' : 'blocked'}`, allowed ? 'success' : 'error');
  } catch(e) { toast('Error: ' + e.message, 'error'); }
}

// ─── SCHEDULES ────────────────────────────────────────────────────────────────
async function renderSchedules() {
  const [schedules, devices] = await Promise.all([api.get('/api/schedules'), api.get('/api/devices')]);
  const DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  document.getElementById('main-content').innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Schedules</div><div class="page-sub">Auto-manage access by time</div></div>
    </div>
    <div class="card">
      <div class="card-header"><span class="card-title">Active schedules</span></div>
      ${schedules.map(s => `
        <div class="item-row">
          <div class="item-info">
            <div class="item-name">${s.name}</div>
            <div class="item-sub">${s.startTime} – ${s.endTime} · ${s.action}</div>
          </div>
          <div style="display:flex;gap:4px;flex-wrap:wrap;max-width:200px;">
            ${DAYS.map(d => `<span style="font-size:10px;padding:2px 6px;border-radius:999px;background:${s.days.includes(d)?'var(--blue-bg)':'var(--surface2)'};color:${s.days.includes(d)?'var(--blue-text)':'var(--text2)'};">${d}</span>`).join('')}
          </div>
          <label class="toggle"><input type="checkbox" ${s.enabled?'checked':''} onchange="toggleSchedule('${s.id}',this.checked)"><span class="toggle-track"></span><span class="toggle-thumb"></span></label>
          <button class="btn btn-sm btn-danger" onclick="deleteSchedule('${s.id}')">Delete</button>
        </div>`).join('')}
    </div>

    <div class="card">
      <div class="card-header"><span class="card-title">Add new schedule</span></div>
      <div class="form-row"><label>Name</label><input type="text" id="sch-name" placeholder="e.g. Bedtime lockdown"></div>
      <div class="form-row"><label>Start time</label><input type="time" id="sch-start" value="22:00"></div>
      <div class="form-row"><label>End time</label><input type="time" id="sch-end" value="06:00"></div>
      <div class="form-row"><label>Days</label>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          ${DAYS.map(d => `<label style="display:flex;align-items:center;gap:4px;font-size:12px;"><input type="checkbox" name="sch-day" value="${d}" checked>${d}</label>`).join('')}
        </div>
      </div>
      <div class="form-row"><label>Apply to</label>
        <select id="sch-apply">
          <option>All devices</option>
          ${devices.filter(d=>d.connected).map(d=>`<option>${d.name}</option>`).join('')}
        </select>
      </div>
      <div class="form-row"><label>Action</label>
        <select id="sch-action">
          <option>Block all traffic</option>
          <option>Block selected apps</option>
          <option>Throttle speed</option>
        </select>
      </div>
      <button class="btn btn-primary" onclick="saveSchedule()">Save schedule</button>
    </div>
  </div>`;
}

async function saveSchedule() {
  const days = [...document.querySelectorAll('input[name="sch-day"]:checked')].map(i=>i.value);
  const body = { name: document.getElementById('sch-name').value, startTime: document.getElementById('sch-start').value, endTime: document.getElementById('sch-end').value, days, applyTo: document.getElementById('sch-apply').value, action: document.getElementById('sch-action').value };
  if (!body.name) return toast('Please enter a schedule name', 'error');
  try { await api.post('/api/schedules', body); toast('Schedule saved!', 'success'); renderSchedules(); }
  catch(e) { toast('Error: ' + e.message, 'error'); }
}

async function toggleSchedule(id, enabled) {
  try { await api.patch(`/api/schedules/${id}`, { enabled }); toast(`Schedule ${enabled?'enabled':'disabled'}`, 'info'); }
  catch(e) { toast('Error: ' + e.message, 'error'); }
}

async function deleteSchedule(id) {
  try { await api.del(`/api/schedules/${id}`); toast('Schedule deleted', 'info'); renderSchedules(); }
  catch(e) { toast('Error: ' + e.message, 'error'); }
}

// ─── ALERTS ──────────────────────────────────────────────────────────────────
async function renderAlerts() {
  const alerts = await api.get('/api/alerts');
  const unread = alerts.filter(a => !a.read);
  const read = alerts.filter(a => a.read);
  const dotColor = t => t==='Security'?'var(--red)':t==='Data'?'var(--yellow)':'var(--green)';

  document.getElementById('main-content').innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Alerts</div><div class="page-sub">Security & data notifications</div></div>
      <button class="btn btn-sm" onclick="markAllRead()">Mark all read</button>
    </div>
    ${unread.length > 0 ? `
    <div class="card">
      <div class="card-header"><span class="card-title">Unread</span><span class="badge badge-red">${unread.length}</span></div>
      ${unread.map(a=>`
        <div class="item-row">
          <div class="alert-dot" style="background:${dotColor(a.type)}"></div>
          <div class="item-info"><div class="item-name">${a.title}</div><div class="item-sub">${a.message} · ${timeAgo(a.time)}</div></div>
          ${makeBadge(a.type)}
          <button class="btn btn-sm" onclick="markRead('${a.id}')">Mark read</button>
        </div>`).join('')}
    </div>` : ''}
    <div class="card">
      <div class="card-header"><span class="card-title">Earlier</span></div>
      ${read.length === 0 ? '<p style="color:var(--text2);font-size:13px;">No older alerts.</p>' :
        read.map(a=>`
        <div class="item-row" style="opacity:0.7">
          <div class="alert-dot" style="background:${dotColor(a.type)}"></div>
          <div class="item-info"><div class="item-name">${a.title}</div><div class="item-sub">${a.message} · ${timeAgo(a.time)}</div></div>
          ${makeBadge(a.type)}
        </div>`).join('')}
    </div>
  </div>`;
}

async function markRead(id) {
  try { await api.patch(`/api/alerts/${id}/read`, {}); renderAlerts(); updateBadges(); }
  catch(e) { toast('Error: ' + e.message, 'error'); }
}

async function markAllRead() {
  try { await api.post('/api/alerts/read-all', {}); toast('All alerts marked as read', 'success'); renderAlerts(); updateBadges(); }
  catch(e) { toast('Error: ' + e.message, 'error'); }
}

// ─── LOGS ─────────────────────────────────────────────────────────────────────
async function renderLogs() {
  const logs = await api.get('/api/logs');
  document.getElementById('main-content').innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Activity log</div><div class="page-sub">Full event history</div></div>
      <button class="btn btn-sm" onclick="exportLogs()">Export CSV</button>
    </div>
    <div class="card">
      ${logs.map(l => `
        <div class="item-row">
          <span class="log-time">${fmtTime(l.time)}</span>
          <span style="flex:1;font-size:13px;color:var(--text)">${l.message}</span>
          ${makeBadge(l.type)}
        </div>`).join('')}
    </div>
  </div>`;
}

function exportLogs() {
  api.get('/api/logs').then(logs => {
    const csv = 'Time,Type,Message\n' + logs.map(l => `"${fmtDate(l.time)}","${l.type}","${l.message}"`).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'hotspothub_logs.csv';
    a.click();
  });
}
