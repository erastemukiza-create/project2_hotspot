let ws;
const wsHandlers = {};

function wsOn(event, fn) { wsHandlers[event] = fn; }

function wsConnect() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(`${proto}://${location.host}`);
  ws.onopen = () => {
    document.getElementById('ws-status').innerHTML = '<span class="ws-dot"></span> Live';
  };
  ws.onmessage = e => {
    try {
      const { event, data } = JSON.parse(e.data);
      if (wsHandlers[event]) wsHandlers[event](data);
      if (wsHandlers['*']) wsHandlers['*'](event, data);
    } catch(_) {}
  };
  ws.onclose = () => {
    document.getElementById('ws-status').innerHTML = '<span class="ws-dot" style="background:var(--red)"></span> Reconnecting...';
    setTimeout(wsConnect, 3000);
  };
}
