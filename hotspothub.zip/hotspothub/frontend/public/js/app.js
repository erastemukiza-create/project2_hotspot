const pages = {
  dashboard: renderDashboard,
  devices: renderDevices,
  apps: renderApps,
  schedules: renderSchedules,
  messages: renderMessages,
  rules: renderRules,
  alerts: renderAlerts,
  logs: renderLogs,
  settings: renderSettings,
};

let currentPage = 'dashboard';

function navigate(page, el) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  if (el) el.classList.add('active');
  currentPage = page;
  if (pages[page]) pages[page]();
}

async function updateBadges() {
  try {
    const [alerts, messages] = await Promise.all([api.get('/api/alerts'), api.get('/api/messages/all').catch(() => [])]);
    const unreadAlerts = alerts.filter(a => !a.read).length;
    const ab = document.getElementById('alert-badge');
    if (ab) { ab.textContent = unreadAlerts; ab.style.display = unreadAlerts > 0 ? 'inline' : 'none'; }
  } catch(_) {}
}

// WebSocket live updates
wsOn('device_updated', () => { if (currentPage === 'devices' || currentPage === 'dashboard') pages[currentPage](); updateBadges(); });
wsOn('new_device', (data) => { toast(`New device: ${data.name} joined!`, 'info'); if (currentPage === 'devices' || currentPage === 'dashboard') pages[currentPage](); updateBadges(); });
wsOn('new_message', (msg) => { if (currentPage === 'messages') renderMessages(); });
wsOn('broadcast_message', () => { if (currentPage === 'messages') renderMessages(); });
wsOn('schedule_created', () => { if (currentPage === 'schedules') renderSchedules(); });
wsOn('schedule_updated', () => { if (currentPage === 'schedules') renderSchedules(); });
wsOn('schedule_deleted', () => { if (currentPage === 'schedules') renderSchedules(); });
wsOn('rules_updated', () => { if (currentPage === 'rules') renderRules(); });
wsOn('settings_updated', (s) => { const el = document.getElementById('phone-model'); if (el && s.phoneModel) el.textContent = s.phoneModel; });
wsOn('devices_synced', () => { if (currentPage === 'dashboard' || currentPage === 'devices') pages[currentPage](); });

// Boot
window.addEventListener('DOMContentLoaded', () => {
  wsConnect();
  navigate('dashboard', document.querySelector('.nav-item[data-page="dashboard"]'));
  updateBadges();
  setInterval(updateBadges, 15000);
});
