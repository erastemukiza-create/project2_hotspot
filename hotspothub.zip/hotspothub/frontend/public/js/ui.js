function toast(msg, type = 'info') {
  const c = document.getElementById('toast-container');
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.textContent = msg;
  c.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

function timeAgo(iso) {
  const diff = (Date.now() - new Date(iso)) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.round(diff/60)} min ago`;
  if (diff < 86400) return `${Math.round(diff/3600)} hr ago`;
  return new Date(iso).toLocaleDateString();
}

function fmtTime(iso) {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function fmtDate(iso) {
  return new Date(iso).toLocaleString();
}

function makeBadge(type) {
  const map = { Security: 'red', Data: 'yellow', Info: 'green', Schedule: 'blue', Device: 'green', AppControl: 'blue' };
  return `<span class="badge badge-${map[type] || 'gray'}">${type}</span>`;
}

function toggleHtml(checked, deviceId, appId) {
  return `<label class="toggle">
    <input type="checkbox" ${checked ? 'checked' : ''} onchange="toggleApp('${deviceId}','${appId}',this.checked)">
    <span class="toggle-track"></span><span class="toggle-thumb"></span>
  </label>`;
}

function blockBtnHtml(device) {
  return device.blocked
    ? `<button class="btn btn-sm btn-danger" onclick="toggleBlock('${device.id}',false)">Unblock</button>`
    : `<button class="btn btn-sm" onclick="toggleBlock('${device.id}',true)">Block</button>`;
}
