# HotspotHub — Full Stack Hotspot Manager

A complete web application to manage your phone's mobile hotspot — view connected devices, block/unblock them, control apps, set schedules, send messages, and publish usage rules.

---

## Project structure

```
hotspothub/
├── backend/
│   ├── server.js       # Express + WebSocket API server
│   ├── db.js           # LowDB database with seed data
│   ├── db.json         # Auto-generated JSON data file
│   └── package.json
└── frontend/
    └── public/
        ├── index.html          # SPA shell
        ├── css/main.css        # All styles
        └── js/
            ├── api.js          # Fetch wrapper
            ├── ws.js           # WebSocket client
            ├── ui.js           # Shared helpers
            ├── app.js          # Router + WS event handlers
            └── pages/
                ├── dashboard.js
                ├── devices.js
                ├── apps.js     # Also contains schedules, alerts, logs
                ├── messages.js
                ├── rules.js
                └── settings.js
```

---

## Quick start

```bash
cd backend
npm install
node server.js
```

Then open → http://localhost:3000

---

## API endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/stats | Summary stats |
| GET | /api/devices | All devices |
| PATCH | /api/devices/:id | Update device (block, unblock) |
| POST | /api/devices/whitelist/:id | Whitelist device |
| DELETE | /api/devices/whitelist/:id | Remove from whitelist |
| GET | /api/apps | All known apps |
| GET | /api/app-rules | All app block rules |
| PATCH | /api/apps/:deviceId/:appId | Set app rule |
| GET | /api/schedules | All schedules |
| POST | /api/schedules | Create schedule |
| PATCH | /api/schedules/:id | Update schedule |
| DELETE | /api/schedules/:id | Delete schedule |
| GET | /api/messages/:deviceId | Messages for a device |
| POST | /api/messages | Send message to device |
| POST | /api/messages/broadcast | Broadcast to multiple devices |
| PATCH | /api/messages/:id/read | Mark message read |
| GET | /api/rules | Get hotspot policy |
| PUT | /api/rules | Update policy |
| GET | /api/alerts | All alerts |
| PATCH | /api/alerts/:id/read | Mark alert read |
| POST | /api/alerts/read-all | Mark all alerts read |
| GET | /api/logs | Activity log |
| GET | /api/settings | Hotspot settings |
| PUT | /api/settings | Update settings |
| POST | /api/phone/sync | Sync devices from phone companion app |

---

## WebSocket events (real-time)

The server broadcasts these events to all connected browser clients:

| Event | Trigger |
|-------|---------|
| `device_updated` | A device is blocked/unblocked |
| `new_device` | A new device joins the hotspot |
| `new_message` | Admin sends a message |
| `broadcast_message` | Broadcast sent to multiple devices |
| `app_rule_updated` | App allowed/blocked |
| `schedule_created/updated/deleted` | Schedule changes |
| `rules_updated` | Policy content changed |
| `settings_updated` | Settings saved |
| `devices_synced` | Phone synced device list |

---

## Connecting your real phone

In production, install a companion Android app that calls:

```
POST /api/phone/sync
Body: { "devices": [ { "name": "...", "mac": "...", "ip": "...", "icon": "📱", "type": "phone", "speed": 2.0, "dataToday": 150 } ] }
```

This endpoint upserts devices by MAC address. Unrecognised MACs trigger a Security alert automatically.

You can also test this via Settings → Phone sync demo panel.

---

## Tech stack

- **Backend**: Node.js, Express, ws (WebSocket), LowDB (JSON file database), UUID
- **Frontend**: Vanilla HTML/CSS/JS — no framework, no build step
- **Real-time**: WebSocket for live device/alert updates
