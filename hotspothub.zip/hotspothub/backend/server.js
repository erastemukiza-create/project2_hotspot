const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const db = require('./db');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend/public')));

// ─── WebSocket broadcast helper ───────────────────────────────────────────────
function broadcast(event, data) {
  const msg = JSON.stringify({ event, data });
  wss.clients.forEach(c => { if (c.readyState === WebSocket.OPEN) c.send(msg); });
}

wss.on('connection', ws => {
  ws.send(JSON.stringify({ event: 'connected', data: { message: 'HotspotHub live feed active' } }));
});

// ─── DEVICES ─────────────────────────────────────────────────────────────────
app.get('/api/devices', (req, res) => res.json(db.get('devices').value()));

app.patch('/api/devices/:id', (req, res) => {
  const device = db.get('devices').find({ id: req.params.id });
  if (!device.value()) return res.status(404).json({ error: 'Device not found' });
  device.assign(req.body).write();
  const updated = device.value();
  // log it
  db.get('logs').push({ id: uuidv4(), time: new Date().toISOString(), type: req.body.blocked ? 'Security' : 'Device', message: `${updated.name} was ${req.body.blocked ? 'blocked' : 'unblocked'} by admin` }).write();
  broadcast('device_updated', updated);
  res.json(updated);
});

app.post('/api/devices/whitelist/:id', (req, res) => {
  const device = db.get('devices').find({ id: req.params.id });
  if (!device.value()) return res.status(404).json({ error: 'Not found' });
  device.assign({ whitelisted: true }).write();
  broadcast('device_updated', device.value());
  res.json(device.value());
});

app.delete('/api/devices/whitelist/:id', (req, res) => {
  const device = db.get('devices').find({ id: req.params.id });
  if (!device.value()) return res.status(404).json({ error: 'Not found' });
  device.assign({ whitelisted: false }).write();
  broadcast('device_updated', device.value());
  res.json(device.value());
});

// ─── APP CONTROL ─────────────────────────────────────────────────────────────
app.get('/api/apps', (req, res) => res.json(db.get('apps').value()));

app.patch('/api/apps/:deviceId/:appId', (req, res) => {
  const rules = db.get('appRules');
  const key = `${req.params.deviceId}_${req.params.appId}`;
  const existing = rules.find({ key }).value();
  if (existing) {
    rules.find({ key }).assign({ allowed: req.body.allowed }).write();
  } else {
    rules.push({ id: uuidv4(), key, deviceId: req.params.deviceId, appId: req.params.appId, allowed: req.body.allowed }).write();
  }
  const apps = db.get('apps').value();
  const app_ = apps.find(a => a.id === req.params.appId);
  const device = db.get('devices').find({ id: req.params.deviceId }).value();
  db.get('logs').push({ id: uuidv4(), time: new Date().toISOString(), type: 'AppControl', message: `${app_ ? app_.name : req.params.appId} ${req.body.allowed ? 'allowed' : 'blocked'} on ${device ? device.name : req.params.deviceId}` }).write();
  broadcast('app_rule_updated', { deviceId: req.params.deviceId, appId: req.params.appId, allowed: req.body.allowed });
  res.json({ key, allowed: req.body.allowed });
});

app.get('/api/app-rules', (req, res) => res.json(db.get('appRules').value()));

// ─── SCHEDULES ────────────────────────────────────────────────────────────────
app.get('/api/schedules', (req, res) => res.json(db.get('schedules').value()));

app.post('/api/schedules', (req, res) => {
  const schedule = { id: uuidv4(), createdAt: new Date().toISOString(), enabled: true, ...req.body };
  db.get('schedules').push(schedule).write();
  broadcast('schedule_created', schedule);
  res.status(201).json(schedule);
});

app.patch('/api/schedules/:id', (req, res) => {
  const s = db.get('schedules').find({ id: req.params.id });
  if (!s.value()) return res.status(404).json({ error: 'Not found' });
  s.assign(req.body).write();
  broadcast('schedule_updated', s.value());
  res.json(s.value());
});

app.delete('/api/schedules/:id', (req, res) => {
  db.get('schedules').remove({ id: req.params.id }).write();
  broadcast('schedule_deleted', { id: req.params.id });
  res.json({ deleted: true });
});

// ─── MESSAGES ─────────────────────────────────────────────────────────────────
app.get('/api/messages/:deviceId', (req, res) => {
  const msgs = db.get('messages').filter({ deviceId: req.params.deviceId }).value();
  res.json(msgs);
});

app.post('/api/messages', (req, res) => {
  const msg = { id: uuidv4(), time: new Date().toISOString(), from: 'admin', read: false, ...req.body };
  db.get('messages').push(msg).write();
  broadcast('new_message', msg);
  res.status(201).json(msg);
});

app.post('/api/messages/broadcast', (req, res) => {
  const { deviceIds, text } = req.body;
  const sent = [];
  deviceIds.forEach(deviceId => {
    const msg = { id: uuidv4(), deviceId, text, from: 'admin', time: new Date().toISOString(), read: false };
    db.get('messages').push(msg).write();
    sent.push(msg);
  });
  broadcast('broadcast_message', { messages: sent });
  res.status(201).json(sent);
});

app.patch('/api/messages/:id/read', (req, res) => {
  const m = db.get('messages').find({ id: req.params.id });
  if (!m.value()) return res.status(404).json({ error: 'Not found' });
  m.assign({ read: true }).write();
  res.json(m.value());
});

// ─── RULES & POLICY ──────────────────────────────────────────────────────────
app.get('/api/rules', (req, res) => res.json(db.get('rules').value()));

app.put('/api/rules', (req, res) => {
  db.set('rules', req.body).write();
  broadcast('rules_updated', req.body);
  res.json(req.body);
});

// ─── ALERTS ──────────────────────────────────────────────────────────────────
app.get('/api/alerts', (req, res) => res.json(db.get('alerts').value()));

app.patch('/api/alerts/:id/read', (req, res) => {
  const a = db.get('alerts').find({ id: req.params.id });
  if (!a.value()) return res.status(404).json({ error: 'Not found' });
  a.assign({ read: true }).write();
  res.json(a.value());
});

app.post('/api/alerts/read-all', (req, res) => {
  db.get('alerts').each(a => { a.read = true; }).write();
  res.json({ ok: true });
});

// ─── ACTIVITY LOG ─────────────────────────────────────────────────────────────
app.get('/api/logs', (req, res) => {
  const logs = db.get('logs').orderBy('time', 'desc').value();
  res.json(logs);
});

// ─── SETTINGS ─────────────────────────────────────────────────────────────────
app.get('/api/settings', (req, res) => res.json(db.get('settings').value()));

app.put('/api/settings', (req, res) => {
  db.set('settings', { ...db.get('settings').value(), ...req.body }).write();
  broadcast('settings_updated', db.get('settings').value());
  res.json(db.get('settings').value());
});

// ─── STATS ────────────────────────────────────────────────────────────────────
app.get('/api/stats', (req, res) => {
  const devices = db.get('devices').value();
  const alerts = db.get('alerts').filter({ read: false }).value();
  res.json({
    connectedDevices: devices.filter(d => d.connected && !d.blocked).length,
    blockedDevices: devices.filter(d => d.blocked).length,
    totalSpeed: devices.filter(d => d.connected && !d.blocked).reduce((s, d) => s + (d.speed || 0), 0).toFixed(1),
    dataUsedToday: devices.reduce((s, d) => s + (d.dataToday || 0), 0).toFixed(0),
    unreadAlerts: alerts.length,
  });
});

// ─── SIMULATE phone pushing device list (demo endpoint) ───────────────────────
app.post('/api/phone/sync', (req, res) => {
  const { devices } = req.body;
  if (!Array.isArray(devices)) return res.status(400).json({ error: 'devices array required' });
  devices.forEach(incoming => {
    const existing = db.get('devices').find({ mac: incoming.mac });
    if (existing.value()) {
      existing.assign({ ...incoming, connected: true, lastSeen: new Date().toISOString() }).write();
    } else {
      const newDev = { id: uuidv4(), connected: true, blocked: false, whitelisted: false, lastSeen: new Date().toISOString(), dataToday: 0, speed: 0, ...incoming };
      db.get('devices').push(newDev).write();
      db.get('alerts').push({ id: uuidv4(), type: 'Security', read: false, time: new Date().toISOString(), title: 'New device detected', message: `${newDev.name || newDev.mac} joined your hotspot` }).write();
      broadcast('new_device', newDev);
    }
  });
  broadcast('devices_synced', db.get('devices').value());
  res.json({ synced: devices.length });
});

// ─── Catch-all → SPA ─────────────────────────────────────────────────────────
app.get('/{*path}', (req, res) => res.sendFile(path.join(__dirname, '../frontend/public/index.html')));

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`HotspotHub running → http://localhost:${PORT}`));
