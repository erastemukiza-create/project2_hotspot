const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const adapter = new FileSync(path.join(__dirname, 'db.json'));
const db = low(adapter);

db.defaults({
  devices: [
    { id: 'd1', name: 'MacBook Pro', mac: 'A1:B2:C3:D4:E5:F6', ip: '192.168.1.2', type: 'laptop', icon: '💻', connected: true, blocked: false, whitelisted: true, speed: 8.4, dataToday: 720, lastSeen: new Date().toISOString() },
    { id: 'd2', name: 'iPhone 15', mac: 'B2:C3:D4:E5:F6:A1', ip: '192.168.1.3', type: 'phone', icon: '📱', connected: true, blocked: false, whitelisted: true, speed: 3.1, dataToday: 310, lastSeen: new Date().toISOString() },
    { id: 'd3', name: 'Unknown device', mac: 'D4:3B:04:AA:12:FF', ip: '192.168.1.4', type: 'unknown', icon: '🖥', connected: true, blocked: true, whitelisted: false, speed: 0, dataToday: 160, lastSeen: new Date().toISOString() },
    { id: 'd4', name: 'Apple Watch', mac: 'C3:D4:E5:F6:A1:B2', ip: '192.168.1.5', type: 'watch', icon: '⌚', connected: true, blocked: false, whitelisted: false, speed: 0.3, dataToday: 30, lastSeen: new Date().toISOString() },
  ],
  apps: [
    { id: 'a1', name: 'YouTube', category: 'Streaming', icon: '▶', speed: 4.8 },
    { id: 'a2', name: 'Spotify', category: 'Streaming', icon: '🎵', speed: 2.1 },
    { id: 'a3', name: 'Netflix', category: 'Streaming', icon: '📺', speed: 5.2 },
    { id: 'a4', name: 'TikTok', category: 'Streaming', icon: '🎬', speed: 3.3 },
    { id: 'a5', name: 'WhatsApp', category: 'Social', icon: '💬', speed: 0.2 },
    { id: 'a6', name: 'Twitter/X', category: 'Social', icon: '🐦', speed: 0.8 },
    { id: 'a7', name: 'Instagram', category: 'Social', icon: '📸', speed: 1.4 },
    { id: 'a8', name: 'Facebook', category: 'Social', icon: '💙', speed: 0.9 },
    { id: 'a9', name: 'PUBG Mobile', category: 'Gaming', icon: '🎮', speed: 1.3 },
    { id: 'a10', name: 'Clash of Clans', category: 'Gaming', icon: '🃏', speed: 0.5 },
    { id: 'a11', name: 'Free Fire', category: 'Gaming', icon: '🔫', speed: 1.1 },
    { id: 'a12', name: 'Chrome', category: 'Browsing', icon: '🌐', speed: 1.9 },
    { id: 'a13', name: 'Firefox', category: 'Browsing', icon: '🦊', speed: 0.7 },
    { id: 'a14', name: 'Torrent client', category: 'Browsing', icon: '📥', speed: 9.4 },
  ],
  appRules: [],
  schedules: [
    { id: 's1', name: 'Night lockdown', startTime: '22:00', endTime: '06:00', days: ['Mon','Tue','Wed','Thu','Fri'], applyTo: 'All devices', action: 'Block all traffic', enabled: true, createdAt: new Date().toISOString() },
    { id: 's2', name: 'Study hours', startTime: '15:00', endTime: '18:00', days: ['Mon','Tue','Wed','Thu','Fri'], applyTo: 'All devices', action: 'Block selected apps', enabled: true, createdAt: new Date().toISOString() },
    { id: 's3', name: 'Weekend free time', startTime: '09:00', endTime: '21:00', days: ['Sat','Sun'], applyTo: 'All devices', action: 'Block all traffic', enabled: false, createdAt: new Date().toISOString() },
  ],
  messages: [
    { id: uuidv4(), deviceId: 'd1', text: 'Hey admin, can I get more bandwidth? Trying to do a video call.', from: 'device', time: new Date(Date.now() - 180000).toISOString(), read: false },
    { id: uuidv4(), deviceId: 'd1', text: 'Sure! I\'ve increased your limit temporarily. Should be better now.', from: 'admin', time: new Date(Date.now() - 120000).toISOString(), read: true },
    { id: uuidv4(), deviceId: 'd1', text: 'Thanks! Much better now 👍', from: 'device', time: new Date(Date.now() - 60000).toISOString(), read: false },
  ],
  alerts: [
    { id: uuidv4(), type: 'Security', read: false, time: new Date(Date.now() - 120000).toISOString(), title: 'Unknown device tried to connect', message: 'MAC: D4:3B:04:AA:12:FF — Auto-blocked' },
    { id: uuidv4(), type: 'Data', read: false, time: new Date(Date.now() - 1080000).toISOString(), title: 'Daily data limit reached', message: '1 GB threshold exceeded' },
    { id: uuidv4(), type: 'Info', read: true, time: new Date(Date.now() - 3600000).toISOString(), title: 'Apple Watch connected', message: '192.168.1.5 joined the hotspot' },
    { id: uuidv4(), type: 'Schedule', read: true, time: new Date(Date.now() - 10800000).toISOString(), title: 'Netflix blocked by schedule', message: 'Study hours rule triggered on MacBook Pro' },
  ],
  logs: [
    { id: uuidv4(), time: new Date(Date.now() - 120000).toISOString(), type: 'Security', message: 'Unknown device D4:3B:04:AA:12:FF attempted to connect — blocked' },
    { id: uuidv4(), time: new Date(Date.now() - 1080000).toISOString(), type: 'Data', message: 'Data usage passed 1 GB threshold' },
    { id: uuidv4(), time: new Date(Date.now() - 3240000).toISOString(), type: 'Schedule', message: 'App block applied: Netflix on MacBook Pro (study hours)' },
    { id: uuidv4(), time: new Date(Date.now() - 3600000).toISOString(), type: 'Device', message: 'Apple Watch connected — 192.168.1.5' },
    { id: uuidv4(), time: new Date(Date.now() - 7200000).toISOString(), type: 'Device', message: 'iPhone 15 connected — 192.168.1.3' },
    { id: uuidv4(), time: new Date(Date.now() - 9000000).toISOString(), type: 'Device', message: 'MacBook Pro connected — 192.168.1.2' },
  ],
  rules: {
    title: 'HotspotHub — Usage policy',
    subtitle: 'Please read and agree before using this network',
    visible: true,
    lastUpdated: new Date().toISOString(),
    sections: [
      { id: 'general', title: 'General use', type: 'info', rules: [
        { id: 1, text: 'This hotspot is for personal use only. Do not share the password with others outside this network.', sub: '' },
        { id: 2, text: 'All devices must be registered and approved by the admin before being granted access.', sub: '' },
        { id: 3, text: 'Usage is limited to a fair daily data cap. Heavy downloads or streaming may be throttled.', sub: 'Current daily limit: 5 GB per device' },
      ]},
      { id: 'prohibited', title: 'Prohibited activities', type: 'warning', rules: [
        { id: 4, text: 'Do not use this network for torrenting, illegal downloads, or accessing pirated content.', sub: '' },
        { id: 5, text: 'Hacking, network scanning, or any activity that disrupts other users is strictly prohibited.', sub: '' },
        { id: 6, text: 'Any attempt to bypass app blocks, schedules, or admin restrictions will result in immediate disconnection.', sub: '' },
        { id: 7, text: 'Accessing illegal, harmful, or inappropriate content is forbidden and may be reported.', sub: '' },
      ]},
      { id: 'privacy', title: 'Data & privacy', type: 'info', rules: [
        { id: 8, text: 'The admin may monitor network traffic, connected devices, and data usage at any time.', sub: '' },
        { id: 9, text: 'Activity logs are kept for security purposes and may be reviewed if a violation is suspected.', sub: '' },
      ]},
      { id: 'scheduling', title: 'Scheduling & availability', type: 'info', rules: [
        { id: 10, text: 'The hotspot may be unavailable during scheduled downtime. Check the notice board for planned outages.', sub: 'Active schedule: Night lockdown 10 PM – 6 AM (Mon–Fri)' },
      ]},
    ],
    rawText: `## General use\n1. This hotspot is for personal use only.\n2. All devices must be registered and approved by the admin.\n3. Usage is limited to a fair daily data cap.\n\n## Prohibited activities\n4. Do not use this network for torrenting or illegal downloads.\n5. Hacking or network scanning is strictly prohibited.\n6. Bypassing restrictions will result in disconnection.\n7. Accessing illegal content is forbidden.\n\n## Data & privacy\n8. The admin may monitor network traffic at any time.\n9. Activity logs are kept for security purposes.\n\n## Scheduling & availability\n10. The hotspot may be unavailable during scheduled downtime.`
  },
  settings: {
    hotspotName: 'My Hotspot',
    password: 'hotspot123',
    maxDevices: 8,
    band: '5 GHz',
    dailyLimit: 5120,
    alertThreshold: 1024,
    autoBlockAtLimit: 'No',
    autoBlockUnknown: true,
    enableSchedules: true,
    twoFactor: true,
    autoLogout: false,
    logAllEvents: true,
    phoneConnected: true,
    phoneModel: 'Samsung Galaxy S24',
    ownerName: 'Jean-Pierre D.',
  },
}).write();

module.exports = db;
